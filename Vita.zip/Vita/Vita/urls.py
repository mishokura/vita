from django.urls import path, include
from django.contrib import admin
from core.views import home, service, about_vita, contact_us
from functions.views import choose_profession, save_quiz_results, pre_choose_profession
urlpatterns = [
    path('', home),
    path('service/', service),
    path('about_vita/', about_vita),
    path('contact_us/', contact_us),
    path('pre_choose_profession/', pre_choose_profession),
    path('choose_profession/', choose_profession),
    path("save_results/", save_quiz_results, name="save_quiz_results"),

    path('account/', include('account.urls')),
    path('admin/', admin.site.urls),
]