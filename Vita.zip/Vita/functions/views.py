from django.http import JsonResponse
from django.shortcuts import render
from django.views.decorators.csrf import csrf_exempt
from django.contrib.auth.decorators import login_required

import json
from .models import Question, profession_results


@login_required
def pre_choose_profession(request):
    past_results = profession_results.objects.filter(user=request.user)[0].results
    past_results = dict(sorted(past_results.items(), key=lambda item: item[1], reverse=True))
    return render(request, 'functions/pre_choose_profession.html', {'past_results':past_results})


@login_required
def choose_profession(request):
    questions_list = []

    questions = Question.objects.prefetch_related('answers').all()
    for question in questions:
        answers = [
            {
                "text": answer.text,
                "professions": answer.profession_scores
            }
            for answer in question.answers.all()
        ]
        questions_list.append({"question": question.text, "answers": answers})

    # Convert Python list to JSON string safely
    questions_json = json.dumps(questions_list)
    past_results = profession_results.objects.filter(user=request.user)
    return render(request, 'functions/choose_profession.html', {'questions_json': questions_json, 'past_results':past_results})



@csrf_exempt
@login_required
def save_quiz_results(request):
    if request.method == "POST":
        try:
            data = json.loads(request.body)
            user = request.user
            profession_results.objects.filter(user=user).delete()
            profession_results.objects.create(user=user, results=data)
            return JsonResponse({"message": "Results saved successfully!"}, status=201)
        except Exception as e:
            return JsonResponse({"error": str(e)}, status=400)
    return JsonResponse({"error": "Invalid request"}, status=400)

