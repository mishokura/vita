from django.shortcuts import render

def home(request):
    return render(request, 'index.html')

def service(request):
    return render(request, 'core/service.html')

def about_vita(request):
    return render(request, 'core/about_vita.html')

def contact_us(request):
    return render(request, 'core/contact_us.html')